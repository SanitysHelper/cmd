/*
 * termUI Portable Launcher
 * Standalone executable that runs termUI directly
 * Compiles to single .exe file
 */

#include <windows.h>
#include <iostream>
#include <string>
#include <shlobj.h>

#pragma comment(lib, "shell32.lib")

int main(int argc, char* argv[]) {
    // Get the directory where the EXE is located
    char exePath[MAX_PATH];
    GetModuleFileNameA(NULL, exePath, MAX_PATH);
    std::string exeDir = exePath;
    size_t lastSlash = exeDir.find_last_of("\\/");
    if (lastSlash != std::string::npos) {
        exeDir = exeDir.substr(0, lastSlash);
    }
    
    // Construct path to run.bat
    std::string runBatPath = exeDir + "\\run.bat";
    
    // Check if run.bat exists
    if (GetFileAttributesA(runBatPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxA(NULL, 
            "Could not find run.bat in the same directory as termUI.exe\n\n"
            "Please ensure termUI.exe is in the termUI folder.",
            "termUI - Error", 
            MB_OK | MB_ICONERROR);
        return 1;
    }
    
    // Build command with any arguments passed to exe
    std::string command = "cmd.exe /c \"cd /d \"" + exeDir + "\" && run.bat";
    
    // Append command line arguments
    for (int i = 1; i < argc; i++) {
        command += " ";
        command += argv[i];
    }
    command += "\"";
    
    // Execute run.bat
    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi;
    
    si.dwFlags = STARTF_USESHOWWINDOW;
    si.wShowWindow = SW_SHOW;
    
    if (!CreateProcessA(
        NULL,
        const_cast<char*>(command.c_str()),
        NULL,
        NULL,
        FALSE,
        0,
        NULL,
        exeDir.c_str(),
        &si,
        &pi
    )) {
        std::string errorMsg = "Failed to launch termUI.\n\nError code: " + std::to_string(GetLastError());
        MessageBoxA(NULL, 
            errorMsg.c_str(),
            "termUI - Error", 
            MB_OK | MB_ICONERROR);
        return 1;
    }
    
    // Wait for the process to complete
    WaitForSingleObject(pi.hProcess, INFINITE);
    
    DWORD exitCode = 0;
    GetExitCodeProcess(pi.hProcess, &exitCode);
    
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);
    
    return exitCode;
}
