---
# Fill in the fields below to create a basic custom agent for your repository.
# The Copilot CLI can be used for local testing: https://gh.io/customagents/cli
# To make this agent available, merge this file into the default repository branch.
# For format details, see: https://gh.io/customagents/config

name:
description:
---

# My Agent

Describe what your agent does here...
this agent will work with just .cpp files. Programs are designed to be easy to follow and easy to understand. These programs are supposed to build data structure libraires like queues, stacks, etc.

update your instructions on what you know about me, my programming style, and remember error handling. when you are running and testing the program, copy the required files into a _debug folder in the same program executable. do your testing there and remember.
update your instructions for clarity once in a while because i am not clear sometimes
