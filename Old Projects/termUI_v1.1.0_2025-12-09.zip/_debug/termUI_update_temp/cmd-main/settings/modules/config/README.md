# Settings Manager 
 
Interactive settings management tool for cmd workspace. 
Run run.bat to view, edit, and add configuration settings. 
