﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 102.209.18.28:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '102.209.18.28:8080'
