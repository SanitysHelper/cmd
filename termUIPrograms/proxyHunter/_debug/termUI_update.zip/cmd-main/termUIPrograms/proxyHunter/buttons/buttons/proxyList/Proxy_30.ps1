﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.122.142.174:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.122.142.174:8080'
