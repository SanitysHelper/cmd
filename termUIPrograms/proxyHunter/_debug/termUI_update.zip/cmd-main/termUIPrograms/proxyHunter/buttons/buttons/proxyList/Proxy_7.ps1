﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 101.200.158.109:3128' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '101.200.158.109:3128'
