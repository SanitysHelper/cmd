﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 1.180.49.222:7302' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '1.180.49.222:7302'
