﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 100.27.183.62:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '100.27.183.62:8080'
