﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.146.170.244:5678' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.146.170.244:5678'
