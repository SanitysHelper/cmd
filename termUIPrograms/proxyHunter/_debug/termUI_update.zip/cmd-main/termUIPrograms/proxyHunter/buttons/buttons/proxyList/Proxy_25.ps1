﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.104.14.224:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.104.14.224:8080'
