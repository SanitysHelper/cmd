﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 102.177.176.47:80' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '102.177.176.47:80'
