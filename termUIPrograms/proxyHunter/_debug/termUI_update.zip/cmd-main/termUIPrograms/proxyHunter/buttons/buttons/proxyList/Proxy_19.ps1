﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 102.210.105.1:82' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '102.210.105.1:82'
