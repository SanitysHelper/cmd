﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.107.84.191:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.107.84.191:8080'
