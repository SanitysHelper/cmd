﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.140.234.38:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.140.234.38:8080'
