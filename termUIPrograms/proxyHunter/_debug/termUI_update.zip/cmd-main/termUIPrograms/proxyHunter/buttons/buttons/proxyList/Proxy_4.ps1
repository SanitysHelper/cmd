﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 1.180.0.162:7302' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '1.180.0.162:7302'
