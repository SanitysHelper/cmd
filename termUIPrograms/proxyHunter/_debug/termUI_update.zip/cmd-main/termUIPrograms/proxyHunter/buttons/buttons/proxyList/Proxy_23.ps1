﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 102.223.9.53:80' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '102.223.9.53:80'
