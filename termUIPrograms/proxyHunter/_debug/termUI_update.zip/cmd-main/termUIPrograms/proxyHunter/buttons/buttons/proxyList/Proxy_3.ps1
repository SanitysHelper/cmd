﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 1.15.158.220:80' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '1.15.158.220:80'
