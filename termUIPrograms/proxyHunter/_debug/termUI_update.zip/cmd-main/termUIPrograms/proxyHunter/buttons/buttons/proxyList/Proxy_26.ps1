﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.104.142.165:8080' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.104.142.165:8080'
