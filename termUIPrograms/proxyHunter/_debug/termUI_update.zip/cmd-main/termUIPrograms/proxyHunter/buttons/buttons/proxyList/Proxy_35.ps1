﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.125.31.222:80' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.125.31.222:80'
