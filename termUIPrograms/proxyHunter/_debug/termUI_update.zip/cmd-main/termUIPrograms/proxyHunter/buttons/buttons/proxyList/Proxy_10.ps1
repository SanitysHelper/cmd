﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 102.165.125.102:5678' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '102.165.125.102:5678'
