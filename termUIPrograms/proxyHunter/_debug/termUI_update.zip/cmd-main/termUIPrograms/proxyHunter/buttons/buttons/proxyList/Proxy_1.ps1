﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 1.1.1.177:80' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '1.1.1.177:80'
