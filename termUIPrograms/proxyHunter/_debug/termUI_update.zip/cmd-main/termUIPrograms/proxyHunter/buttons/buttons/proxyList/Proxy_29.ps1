﻿$ErrorActionPreference = "Stop"
Write-Host 'Proxy: 103.116.7.130:80' -ForegroundColor Green
Write-Host 'Copied to clipboard.' -ForegroundColor DarkGray
Set-Clipboard '103.116.7.130:80'
